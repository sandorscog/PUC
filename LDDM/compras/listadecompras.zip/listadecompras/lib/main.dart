import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

List<Item> lista = [];
int pos;

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de compra',
      theme: ThemeData(
        primarySwatch: Colors.red,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black54,

        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Lista de compras'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  AudioPlayer player = AudioPlayer();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text('Menu'),
              decoration: BoxDecoration(
                color: Colors.grey,
              ),
            ),

            ListTile(
              title: Text('Cadastro'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => cadastro()
                  ),
                );
              },
            ),
          ],
        ),
      ),

      body: _body(),

    );
  }

  _body(){
    final nome = TextEditingController();
    final dados = TextEditingController();
    //final nome = TextEditingController();
    //lista.add(Item("go", "back", "home"));


    return Column(
      children: <Widget>[
        _refresh(),
        Expanded(
          child: ListView.builder(
            itemCount: lista.length,
            itemBuilder: (BuildContext context, int index){
              return Container(

                child: FlatButton(

                  onPressed: () {
                    show(index, context);

                  },

                  onLongPress: (){
                    nome.text = lista[index].nome;
                    dados.text = lista[index].dados;

                    showDialog(
                        context: context,
                        builder: (context){
                          return AlertDialog(
                            backgroundColor: Colors.grey,
                            title: Text("Opcoes: "),
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _editText("", nome),
                                _editText("", dados),
                              ],

                            ),

                            actions: <Widget>[
                              FlatButton(
                                textColor: Colors.lightGreenAccent,
                                onPressed: () async{
                                  FirebaseFirestore.instance.collection("colecao").where("nome", isEqualTo: lista[index].nome).get().
                                  then((QuerySnapshot snap) async{
                                    if(snap.docs.isNotEmpty)
                                      await FirebaseFirestore.instance.collection("colecao").doc(snap.docs.first.id).delete();
                                  });
                                  setState((){
                                    lista.removeAt(index);
                                  });

                                  Navigator.pop(context);
                                },
                                  child: Text("deletar")
                              ),

                              FlatButton(
                                textColor: Colors.lightGreenAccent,

                                  onPressed: () async{
                                    setState(() {
                                      lista[index].nome = nome.text;
                                      lista[index].dados = dados.text;
                                    });

                                    FirebaseFirestore.instance.collection("colecao").where("nome", isEqualTo: lista[index].nome).get().
                                    then((QuerySnapshot snap) async{
                                      if(snap.docs.isNotEmpty)
                                        await FirebaseFirestore.instance.collection("colecao").doc(snap.docs.first.id).update({
                                          "nome": nome.text,
                                          "dados" : dados.text,
                                        });
                                    });

                                    Navigator.pop(context);
                                  },
                                  child: Text("Atulizar")
                              )
                            ]
                          );
                        }
                    );
                  },

                  child: Row(
                    //mainAxisAlignment: MainAxisAlignment,
                    children: [
                      Container(
                          height: 100,
                          width: 100,
                          child: Image.file(File(lista[index].image), fit: BoxFit.fitWidth),
                      ),
                      Text(
                          "     " + lista[index].nome,
                          style: TextStyle(fontSize: 25, color: Colors.red),
                      ),
                    ],
                  ),

                ),

              );
            },
          ),
        )
      ],
    );
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  show(int i, BuildContext context) {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Detalhes\n",
              style: TextStyle(
                fontSize: 28,
              ),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(lista[i].dados + "\n\n"),
                _audio(i),
                Container(
                  height: 250,
                  width: 250,
                  child: Image.file(File(lista[i].image), fit: BoxFit.fitWidth),
                ),
              ],
            ),
          );
        }
    );
  }

  _audio(int i) {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Play",
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
          ),
          onPressed: () async{
            await player.play(lista[i].audio, isLocal: true);
          }
      ),
    );
  }

  _refresh(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Refresh",
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
          ),
          onPressed: () async{
            lista.clear();
            FirebaseFirestore.instance.collection("colecao")
                .get()
                .then((QuerySnapshot snap) {
              setState(() {
                for (QueryDocumentSnapshot doc in snap.docs) {
                  lista.add(
                      Item(
                        doc.get("nome"),
                        doc.get("dados"),
                        doc.get("image"),
                        doc.get("audio"),
                      )
                  );
                }
              });
            });
          }
      ),
    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }
}

class cadastro extends StatefulWidget {
  @override
  _cadastroState createState() => _cadastroState();
}

class _cadastroState extends State<cadastro> {
  final nome = TextEditingController();
  final dados = TextEditingController();
  String imagem = "", audio = "";


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Casdastro"),
      ),

      body: _body(),
    );
  }

  _body(){
    return SingleChildScrollView(
      child: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _editText("nome:", nome),
            _editText("detalhes:", dados),
            _file(FileType.image, "imagem"),
            _file(FileType.audio, "audio"),
            _registrar(),
          ],

        ),
      ),
    );
  }

  _file(FileType tipo, String t) {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Escolher " + t,
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),

          onPressed: () async{
            FilePickerResult arq = await FilePicker.platform.pickFiles(type: tipo);
            if(arq != null){
              if(t.contains("imagem")){
                imagem = arq.paths.single;
              } else {
                audio = arq.paths.single;
              }

            }
          }
      ),


    );


  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  _registrar(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.red,
        child:
          Text(
            "Cadastrar",
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),

         onPressed: () async{
            Item i = Item(nome.text, dados.text, imagem, audio);
            Map<String, dynamic> json = i.mapper();
            await FirebaseFirestore.instance.collection("colecao").add(json);
            setState(() {
              lista.add(i);
            });
         }
      ),


    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

}



class Item{
  String nome = "";
  String dados = "";
  String image = "";
  String audio = "";

  Item(String n, String d, String i, String a){
    nome = n;
    dados = d;
    image = i;
    audio = a;
  }

  Map<String,dynamic> mapper(){
    return {
      "nome": nome,
      "dados" : dados,
      "image" : image,
      "audio" : audio,
    };
  }
}

