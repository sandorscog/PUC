package com.example.listadecompras

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
