import 'package:entrada_dados_app/EntradaRadioButton.dart';
import 'package:entrada_dados_app/EntradaSlider.dart';
import 'package:entrada_dados_app/EntradaSwitch.dart';
import 'package:flutter/material.dart';
import 'CampoTexto.dart';
import 'EntradaCheckBox.dart';

void main() {
  runApp(MaterialApp(
    //home: CampoTexto(),
    //home: EntradaCheckBox(),
    //home: EntradaRadioButton(),
    //home: EntradaSwitch(),
    home: EntradaSlider(),
  ));
}
