import 'package:flutter/material.dart';
import 'dart:math';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MaterialApp(
      home: MyApp()));
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black54,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();

}

class _MyHomePageState extends State<MyHomePage> {

  var _formKey = GlobalKey<FormState>();
  final user = TextEditingController();
  final pass = TextEditingController();
  var _infoText = "Informe seus dados!";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tarefas"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.refresh),
              onPressed: _resetFields)
        ],
      ),
      body: _body(),
    );

  }

  void _resetFields(){
    user.text = "";
    pass.text = "";
    setState(() {
      _formKey = GlobalKey<FormState>();
    });
  }

  _textInfo() {
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.blue, fontSize: 25.0),
    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  _body(){
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editText("User", user),
              _editText("password", pass),
              _buttonLogin(),
              _buttonRegistrar(),
              _textInfo(),
            ],
          ),
        ));
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  _buttonLogin(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Login",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () async {
          final SharedPreferences prefs = await SharedPreferences.getInstance();
          final String login = await prefs.getString("user");
          final String senha = await prefs.getString("pass");
          //checa no shared preferences se o login e valido
          if(login == user.text && pass.text == senha ) {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => lista()
              ),
            );

          } else {
            setState(() {
              _infoText = "login incorreto";
            });

          }
        },
      ),
    );
  }

  _buttonRegistrar(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.red,
        child:
        Text(
          "Registrar",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () async{
          String valorDigitado = user.text;
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString("user", valorDigitado);
          valorDigitado = pass.text;
          await prefs.setString("pass", valorDigitado);
        },
      ),
    );
  }

}

/*----------------------------------------------------------------------------*/
class lista extends StatefulWidget {
  @override
  _listaState createState() => _listaState();
}

class _listaState extends State<lista> {
  final user = TextEditingController();

  List<tupla> lista = [];

  @override
  void initState() {
    listagem().then((List<tupla> rec){
      setState(() {
        lista = rec;
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lista de Tarefas"),
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.pink,
          elevation: 6,
          child: Icon(Icons.add),
          onPressed: (){
            print("Botão pressionado!");
            showDialog(
                context: context,
                builder: (context){
                  return AlertDialog(
                    backgroundColor: Colors.blueAccent,
                    title: Text("Adicionar Tarefa: "),
                      content:
                        _editText("Tarefa", user),
                    actions: <Widget>[
                      FlatButton(
                          textColor: Colors.yellow,
                          onPressed: (){
                            Navigator.pop(context);
                          },
                          child: Text("Cancelar")
                      ),
                      FlatButton(
                          textColor: Colors.yellow,
                          onPressed: () async{
                            Database bd = await _recuperarBancoDados();
                            Map<String, dynamic> tarefa = {
                              "task" : user.text,
                            };
                            int id = await bd.insert("tarefas", tarefa);
                            print(id);
                            setState(() {
                              lista.add(tupla(id,user.text));
                            });
                            Navigator.pop(context);
                          },
                          child: Text("Salvar")
                      ),
                    ],

                  );
                }
            );
          }
      ),

      /**********************************************************************/
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
                itemCount: lista.length,
                itemBuilder: (context, index){
                  return ListTile(
                    title: Text(lista[index].tarefa),
                    onTap: () async{
                      showDialog(
                          context: context,
                          builder: (context){
                            return AlertDialog(
                              backgroundColor: Colors.green,
                              title: Text("Adicionar Tarefa: "),
                              content:
                              _editText("Tarefa", user),
                              actions: <Widget>[
                                FlatButton(
                                    textColor: Colors.yellow,
                                    onPressed: (){
                                      Navigator.pop(context);
                                    },
                                    child: Text("Cancelar")
                                ),
                                FlatButton(
                                    textColor: Colors.yellow,
                                    onPressed: () async{
                                      Database bd = await _recuperarBancoDados();
                                      Map<String, dynamic> tarefa = {
                                        "task" : user.text,
                                      };
                                      await bd.update("tarefas", tarefa, where: "id=?", whereArgs:[lista[index].id]);
                                      setState(() {
                                        lista[index].tarefa = user.text;
                                      });
                                      Navigator.pop(context);
                                    },
                                    child: Text("Salvar")
                                ),
                              ],

                            );
                          }
                      );
                    },
                    onLongPress: () async{
                      Database bd = await _recuperarBancoDados();
                      bd.delete("tarefas", where: "id=?", whereArgs: [lista[index].id]);
                      setState(() {
                        lista.remove(lista[index]);
                      });
                    },
                  );
                }
            ),
          ),
        ],
      ),
    );
  }

  Future<List<tupla>> listagem() async{
    Database db = await _recuperarBancoDados();
    List<Map<String, dynamic>> tuplas = await db.rawQuery("SELECT * FROM tarefas");
    List<tupla> resp = [];
    for(Map<String,dynamic> tasks in tuplas){
      resp.add(tupla(tasks["id"], tasks["task"]));
    }
    return resp;
  }

  _recuperarBancoDados() async {
    final caminhoBancoDados = await getDatabasesPath();
    final localBancoDados = path.join(caminhoBancoDados, "dadosMuitoBons.bd");
    var bd = await openDatabase(
        localBancoDados,
        version: 1,
        onCreate: (db, dbVersaoRecente){
          db.execute("CREATE TABLE tarefas (id INTEGER PRIMARY KEY AUTOINCREMENT, task VARCHAR) ");
        }
    );
    return bd;
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.red,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.black,
        ),
      ),
    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

}

/*----------------------------------------------------------------------------*/
class tupla{
  int id = -1;
  String tarefa = "";

  tupla(i,str){
    id = i;
    tarefa = str;
  }
}