package com.example.listinha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
