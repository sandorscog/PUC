import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final temp = TextEditingController();
  var _formKey = GlobalKey<FormState>();
  var _infoText = "Informe a temperatura";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Conversor de Temperatura"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.refresh),
              onPressed: _resetFields)
        ],
      ),
      body: _body(),
    );
  }

  void _resetFields(){
    temp.text = "";
    setState(() {
      _infoText = "Informe a temperatura";
      _formKey = GlobalKey<FormState>();
    });
  }

  void _calculateKelvin(){
    setState(() {
      _infoText = (int.parse(temp.text)-273).toString();
    });
  }

  void _calculateFarenheit(){
    setState(() {
      _infoText = ((int.parse(temp.text)*1.8)+32).toString();
    });
  }

  void _calculateRankine(){
    setState(() {
      _infoText = ((int.parse(temp.text)*1.8)+491.67).toStringAsPrecision(5);
    });
  }

  void _calculateReaumur(){
    setState(() {
      _infoText = (int.parse(temp.text)*0.8).toStringAsPrecision(5);
    });
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  _body() {
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editText("Temp: (C°)", temp),
              _buttonKelvin(),
              _buttonFarenheit(),
              _buttonRankine(),
              _buttonReaumur(),
              _textInfo(),
            ],
          ),
        ));
  }

  _editText(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.black,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  // Widget button
  _buttonKelvin() {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Kelvin",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if(_formKey.currentState.validate()){
            _calculateKelvin();
          }
        },
      ),
    );
  }

  _buttonFarenheit() {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.orange,
        child:
        Text(
          "Farenheit",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if(_formKey.currentState.validate()){
            _calculateFarenheit();
          }
        },
      ),
    );
  }

  _buttonRankine() {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.deepOrange,
        child:
        Text(
          "Rankine",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if(_formKey.currentState.validate()){
            _calculateRankine();
          }
        },
      ),
    );
  }

  _buttonReaumur() {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.red,
        child:
        Text(
          "Reaumur",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if(_formKey.currentState.validate()){
            _calculateReaumur();
          }
        },
      ),
    );
  }

  _textInfo() {
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black, fontSize: 25.0),
    );
  }

}
