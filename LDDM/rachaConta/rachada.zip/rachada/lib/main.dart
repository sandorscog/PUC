import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final temp = TextEditingController();
  final numPessoas = TextEditingController();
  final bebados = TextEditingController();
  final precoBebidas = TextEditingController();
  var _formKey = GlobalKey<FormState>();
  var _infoText = "Racha conta";
  double _currentSliderValue = 20;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Racha conta"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.refresh),
              onPressed: _resetFields)
        ],
      ),
      body: _body(),
    );
  }

  void _resetFields(){
    temp.text = "";
    setState(() {
      _infoText = "Informe a temperatura";
      _formKey = GlobalKey<FormState>();
    });
  }

  void _calculateKelvin(){
    setState(() {
      double base = (double.parse(temp.text)/double.parse(numPessoas.text));
      double total = double.parse(temp.text) + double.parse(precoBebidas.text);
      double tip = total * _currentSliderValue/100;
      _infoText = "Valor a ser pago: " + base.toStringAsFixed(2) + "\n" + "Valor para quem bebe: "
                  + (base + (double.parse(precoBebidas.text)/double.parse(bebados.text))).toStringAsFixed(2)
                  + "\nValor para o garçom: " + tip.toStringAsFixed(2)
                  + "\nTotal: " + (total).toStringAsFixed(2);
    });
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  _body() {
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editTextConta("Valor da conta", temp),
              _editTextNumPessoas("Num Pessoas", numPessoas),
              _editTextNumBebados("Num de pessoas que bebem", bebados),
              _editTextPrecoBebados("Preco das bebidas", precoBebidas),
              Text('Porcentagem do garçom:', textAlign: TextAlign.center, style: TextStyle(fontSize: 25.0)),
              slider(),
              _buttonKelvin(),
              _textInfo(),
            ],
          ),
        ));
  }

  _editTextConta(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.brown,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.blueGrey,
        ),
      ),
    );
  }
  _editTextNumPessoas(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.greenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.red,
        ),
      ),
    );
  }

  _editTextNumBebados(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.red,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.teal,
        ),
      ),
    );
  }

  _editTextPrecoBebados(String field, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.pinkAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.blue,
        ),
      ),
    );
  }

  // Widget button
  _buttonKelvin() {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Calcular",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          if(_formKey.currentState.validate()){
            _calculateKelvin();
          }
        },
      ),
    );
  }

  slider() {
    return Slider(
      value: _currentSliderValue,
      min: 0,
      max: 100,
      divisions: 20,
      label: _currentSliderValue.round().toString(),
      onChanged: (double value) {
        setState(() {
          _currentSliderValue = value;
        });
      },
    );
  }

  _textInfo() {
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black, fontSize: 25.0),
    );
  }

}


