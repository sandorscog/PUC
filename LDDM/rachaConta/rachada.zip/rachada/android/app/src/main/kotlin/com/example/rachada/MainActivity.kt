package com.example.rachada

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
