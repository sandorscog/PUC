import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MaterialApp(
      home: MyApp()));
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black54,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();

}

class _MyHomePageState extends State<MyHomePage> {

  var _formKey = GlobalKey<FormState>();
  final user = TextEditingController();
  final pass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Joguin"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.refresh),
              onPressed: _resetFields)
        ],
      ),
      body: _body(),
    );

  }

  void _resetFields(){
    user.text = "";
    pass.text = "";
    setState(() {
      _formKey = GlobalKey<FormState>();
    });
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  _body(){
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editText("User", user),
              _editText("password", pass),
              _buttonLogin(),
            ],
          ),
        ));
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  _buttonLogin(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Login",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => menuDeEscolha()
            ),
          );
        },
      ),
    );
  }

}

/*----------------------------------------------------------------------------*/
class menuDeEscolha extends StatefulWidget {
  @override
  _menuDeEscolhaState createState() => _menuDeEscolhaState();
}

class _menuDeEscolhaState extends State<menuDeEscolha> {

  var _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('joguin'),
      ),
      body: _body(),
    );
  }


  _body() {
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _buttonAdivinha(),
              _buttonRiddle(),
              _buttonTutorial(),
            ],
          ),
        ));
  }

  _buttonAdivinha(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Jogo do Adivinha",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          /*chama a proxima tela*/
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => adivinha()
            ),
          );
        },
      ),
    );
  }

  _buttonRiddle(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Jogo das charadas",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          /*chama a proxima tela*/
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => riddle()
            ),
          );
        },
      ),
    );
  }

  _buttonTutorial(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Tutoriais",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          /*chama a proxima tela*/
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => tutoriais()
            ),
          );
        },
      ),
    );
  }

}

/*----------------------------------------------------------------------------*/
class tutoriais extends StatefulWidget {
  @override
  _tutoriaisState createState() => _tutoriaisState();
}

class _tutoriaisState extends State<tutoriais> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tutoriais"),
      ),
      body: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            children: <Widget>[
              Text("\n1- Jogo do adivinha\num número aleatório é gerado\ncaso você não acerte uma dica será dada\nquando acertar o programa diz o número de tentativas"
                  "\n\n\n2- Jogo das charadas:\nvarias charadas serão apresentadas\npara todo acerto +1 ponto\nescreva tudo em letras minúsculas"),
            ],
          )
      ),
    );
  }
}
/*----------------------------------------------------------------------------*/
class adivinha extends StatefulWidget {
  @override
  _adivinhaState createState() => _adivinhaState();
}

class _adivinhaState extends State<adivinha> {

  var _formKey = GlobalKey<FormState>();
  final num = TextEditingController();
  var _infoText = "Tente um número";
  int resp = -1;
  int count = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('joguin'),
      ),
      body: _body(),
    );
  }

  _body(){
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _editText("Num", num),
              _buttonTenta(),
              _buttonGera(),
              _textInfo(),
            ],
          ),
        ));
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.number,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  _buttonTenta(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Tentar",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          /*checa o numero e da o resultado*/
          setState(() {
            check(int.parse(num.text));
          });

        },
      ),
    );
  }

  _buttonGera(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Gera novo número",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          //gera um numero e reseta o counter
          count = 0;
          geraNum();
        },
      ),
    );
  }

  _textInfo() {
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.lightGreenAccent, fontSize: 25.0),
    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  void geraNum(){
    var rng = new Random();
    resp = rng.nextInt(100);
  }

  void check(int i){
    if(resp == -1) geraNum();

    if(i == resp){
      geraNum();
      _infoText = "voce acertou!\n foram necessarias $count tentativas";
      count = 0;
    } else {
      count++;
      if(i > resp){
        //mais baixo
        _infoText = "mais baixo";
      } else {
        //mais alto
        _infoText = "mais alto";
      }

    }
  }
}

/*----------------------------------------------------------------------------*/
class riddle extends StatefulWidget {
  @override
  _riddleState createState() => _riddleState();
}

class _riddleState extends State<riddle> {

  int count = 0;
  int j = 0;
  var _formKey = GlobalKey<FormState>();
  var _infoText = "";
  var frases = ['O que tem raízes que ninguem vê, é mais alto que as árvores, vai muito alto, porém nunca cresce?',
                'Trinta cavalos brancos em um morro vermelho, primeiro eles mordem, depois eles carimbam, por fim ficam parados',
                'Chora sem voz, palpita sem asas, morde sem dentes, murmura sem boca',
                'Um olho em um rosto azul viu um olho em um rosto verde. \"Esse olho é como este olho\", disse o primeiro olho, \'porém em um local baixo e não em um alto\'',
                'Não pode ser visto, não pode ser sentido, não pode ser escutado, não pode ser cheirado. Fica atrás das estrelas e embaixo dos morros. Preenche espaços vazios. Vem primeiro e segue atrás, acaba a vida e mata risos',
                'Uma caixa sem alças, chave ou tampa, ainda assim um tesouro dourado esconde',
                'Vivo sem ar, frio como a morte, nunca tem sede, sempre bebendo, todo de armadura porém nunca tilinta',
                'Devora tudo, aves, feras, árvores, flores, roe ferro, torna pedra em poeira, mata reis, destroi cidades e abaixa montanhas até suas bases',
                'O que está no meu bolso?'];
  var resp = ['montanha','dentes','vento','sol nas margaridas','escuro','ovo','peixe','tempo','o anel'];
  var frase = "";
  final palavra = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('joguin'),
      ),
      body: _body(),
    );
  }

  _body(){
    return SingleChildScrollView(
        padding: EdgeInsets.all(15.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              _riddle(),
              _editText("texto", palavra),
              _buttonTenta(),
              //_textInfo(),
            ],
          ),
        ));
  }

  _riddle(){
    if(j < 9) {
      return Text(
        frases[j],
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.lightGreenAccent, fontSize: 25.0),
      );
    }else{
      return Text(
        "Acertos: $count",
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.lightGreenAccent, fontSize: 25.0),
      );
    }
  }

  _textInfo(){
    return Text(
      _infoText,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.lightGreenAccent, fontSize: 25.0),
    );
  }

  _buttonTenta(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
        color: Colors.yellow,
        child:
        Text(
          "Tentar",
          style: TextStyle(
            color: Colors.black,
            fontSize: 22,
          ),
        ),
        onPressed: () {
          /*checa o numero e da o resultado*/
          setState(() {
            check(palavra.text);
          }
          );


        },
      ),
    );
  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

  void check(String i){
    if(j < 9) {
      if (i.compareTo(resp[j]) == 0) {
        count++;
      }
      j++;
      _infoText = "Acertos: $count";

    } else {
      j = 0;
      count = 0;
    }

  }
}
