import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:sensors/sensors.dart';

List<Item> lista = [];
int index;

void main() async{
  index = 0;
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Visualizador',
      theme: ThemeData(
        primarySwatch: Colors.red,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black54,

        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Visualizador'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  AudioPlayer player = AudioPlayer();
  bool inclina = true;

  @override
  void initState() {
    initLista();

      accelerometerEvents.listen((event) {
        print(event);
        if(lista.length > 0) {
          if (event.x > 5 && inclina) {
            setState(() {
              index--;
              if (index < 0) index = lista.length - 1;
              inclina = false;
              Future.delayed(Duration(milliseconds: 1500), () {
                inclina = true;
              });
            });
          } else if (event.x < -5 && inclina) {
            setState(() {
            index++;
            if (index == lista.length) index = 0;
            inclina = false;
            Future.delayed(Duration(milliseconds: 1500), () {
              inclina = true;
            });
          });
          }
        }

        print("$index ***************************************** ${lista.length}");
      });


    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text('Menu'),
              decoration: BoxDecoration(
                color: Colors.grey,
              ),
            ),

            ListTile(
              title: Text('Adicionar'),
              onTap: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => cadastro()
                  ),
                );
                setState(() {});
              },
            ),
          ],
        ),
      ),


      body: lista.length != 0 ?
      Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
          child: FlatButton(
              child: Image.file(File(lista[index].image), fit: BoxFit.fitWidth),
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (context){
                      return AlertDialog(
                          backgroundColor: Colors.grey,

                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(lista[index].dados + "\n\n"),
                              _audio(index),
                            ],
                          ),


                          actions: <Widget>[
                            FlatButton(
                                textColor: Colors.lightGreenAccent,
                                onPressed: () async{
                                  FirebaseFirestore.instance.collection("colecao").where("dados", isEqualTo: lista[index].dados).get().
                                  then((QuerySnapshot snap) async{
                                    if(snap.docs.isNotEmpty)
                                      await FirebaseFirestore.instance.collection("colecao").doc(snap.docs.first.id).delete();
                                  });
                                  setState((){
                                    lista.removeAt(index);
                                  });

                                  Navigator.pop(context);
                                },
                                child: Text("deletar")
                            ),

                          ]
                      );
                    }
                );
              },
          ),
      ) :
      Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Align(child: Text("Não existem imagens na lista", style: TextStyle(
          fontSize: 30,
        ),),),
      ),
    );
  }

  _audio(int i) {
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Play",
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
            ),
          ),
          onPressed: () async{
            await player.play(lista[i].audio, isLocal: true);
          }
      ),
    );
  }

  initLista() async{
    lista.clear();
    FirebaseFirestore.instance.collection("colecao")
        .get()
        .then((QuerySnapshot snap) {
      setState(() {
        for (QueryDocumentSnapshot doc in snap.docs) {
          lista.add(
              Item(
                doc.get("dados"),
                doc.get("image"),
                doc.get("audio"),
              )
          );
        }
      });
    });
  }
}

class cadastro extends StatefulWidget {
  @override
  _cadastroState createState() => _cadastroState();
}

class _cadastroState extends State<cadastro> {
  final dados = TextEditingController();
  String imagem = "", audio = "";


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Adicionar"),
      ),

      body: _body(),
    );
  }

  _body(){
    return SingleChildScrollView(
      child: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _editText("detalhes:", dados),
            Row(
              children:[
                _file(FileType.image, "imagem"),
                _file(FileType.audio, "audio"),
              ]
            ),
            _registrar(),
          ],

        ),
      ),
    );
  }

  _file(FileType tipo, String t) {
    return Container(
      width: MediaQuery.of(context).size.width/2,
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Escolher " + t,
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),

          onPressed: () async{
            FilePickerResult arq = await FilePicker.platform.pickFiles(type: tipo);
            if(arq != null){
              if(t.contains("imagem")){
                imagem = arq.paths.single;
              } else {
                audio = arq.paths.single;
              }

            }
          }
      ),


    );


  }

  _editText(String field, TextEditingController controller){
    return TextFormField(
      controller: controller,
      validator: (s) => _validate(s, field),
      keyboardType: TextInputType.text,
      style: TextStyle(
        fontSize: 22,
        color: Colors.lightGreenAccent,
      ),
      decoration: InputDecoration(
        labelText: field,
        labelStyle: TextStyle(
          fontSize: 22,
          color: Colors.grey,
        ),
      ),
    );
  }

  _registrar(){
    return Container(
      margin: EdgeInsets.only(top: 5.0, bottom: 5),
      height: 45,
      child: RaisedButton(
          color: Colors.red,
          child:
          Text(
            "Cadastrar",
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),

          onPressed: () async{
            Item i = Item(dados.text, imagem, audio);
            Map<String, dynamic> json = i.mapper();
            await FirebaseFirestore.instance.collection("colecao").add(json);
            setState(() {
              lista.add(i);
              index = 0;
            });
          }
      ),


    );
  }

  String _validate(String text, String field) {
    if (text.isEmpty) {
      return "Digite $field";
    }
    return null;
  }

}

class Item{
  String dados = "";
  String image = "";
  String audio = "";

  Item(String d, String i, String a){
    dados = d;
    image = i;
    audio = a;
  }

  Map<String,dynamic> mapper(){
    return {
      "dados" : dados,
      "image" : image,
      "audio" : audio,
    };
  }
}
